import PlaygroundSupport
import SpriteKit
import UIKit

let page = PlaygroundPage.current
page.liveView = GameViewController()
