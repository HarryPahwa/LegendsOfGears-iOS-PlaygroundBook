import Foundation
import SpriteKit

public struct gearNodes {
    var teeth: Int
    var radius: Double
    var module: Double
    var node: SKNode
}
