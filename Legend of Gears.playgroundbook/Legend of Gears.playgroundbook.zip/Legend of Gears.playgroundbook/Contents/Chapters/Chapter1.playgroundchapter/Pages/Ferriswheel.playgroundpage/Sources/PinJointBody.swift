import Foundation
import SpriteKit

public struct PinJointBody {
    var gear: SKShapeNode
    var pin: SKShapeNode
}
