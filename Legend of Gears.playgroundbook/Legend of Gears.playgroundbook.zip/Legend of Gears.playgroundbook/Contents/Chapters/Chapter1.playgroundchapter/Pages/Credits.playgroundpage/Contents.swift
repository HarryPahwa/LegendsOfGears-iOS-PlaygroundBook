/*:
 **Credits:**
 
 * "Enchanted Festival.mp3":
  Music by Matthew Pablo
  (http://www.matthewpablo.com).
  Artist: Matthew Pablo.
  Creation: 2013
 
 
 * "Grassy World.mp3":
  Music by Matthew Pablo
  (http://www.matthewpablo.com).
  Artist: Matthew Pablo.
  Creation: 2012
 
 
 * "Delete_Empty.png, Delete_Full.png, Pause.png, Play.png, Next.png": Icon pack by Icons8 (https://icons8.com, usage with attribution)
 
 * "Ground": Creative Commons License by pixabay.com (https://pixabay.com/en/hill-soil-grass-ground-meadow-576592/)
 
 * "Gear Cog" (presentation): Creative Commons License by pixabay.com (https://pixabay.com/en/cog-wheel-gear-chrome-engineering-24278/)
 
 * "Ferris Wheel": Creative Commons License by pixabay.com (https://pixabay.com/en/ferris-wheel-eye-gray-ride-grey-304582/)
 
 * "gears.jpg (PlaygroundBook Logo)": Creative Commons License by pixabay.com (https://pixabay.com/en/close-up-cogs-gears-machine-1853057/)
 */
